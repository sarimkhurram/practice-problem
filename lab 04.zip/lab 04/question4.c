#include <stdio.h>

int main(){
    int income ;
    float tax = 0.0f  ;
    printf("Enter your income : ") ;
    scanf("%d",&income) ;
    if(income>0 && income <=250000){
        tax = income*0.0f ;
    }
    else if(income>=2500001 && income <=500000){
        tax = income * 0.05f ;
    }
    else if (income>=500001 && income <=1000000){
        tax = income * 0.2f ;
    }
    else if (income>1000000)
    {
        tax = income * 0.3f ;
    }

    float net_amount = income - tax ;
    printf("Your Amount is Rs%d\n",income) ;
    printf("Your Tax Amount is Rs%.2f\n",tax) ;
    printf("Your Net Amount is Rs%.2f\n",net_amount) ;

    
    return 0 ;

}