#include <stdio.h>

int main(){
    int marks ;
    printf("Enter marks out of 100 : ") ;
    scanf("%d",&marks) ;

    if(marks>=90){
        printf("A Grade") ;
    }
    else if(marks>=80 && marks<90){
        printf("B Grade") ;
    }
    else if(marks>=70 && marks<80){
        printf("c  Grade") ;
    }
    else if(marks>=60 && marks<70){
        printf("D Grade") ;
    }
    
    else{
        printf("Fail") ;
    }

    return 0 ;
}