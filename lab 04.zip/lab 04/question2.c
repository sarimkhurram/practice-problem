#include <stdio.h>

int main(){
    char character ;
    printf("Enter a small character to check if it is vowel or consonant : ") ;
    scanf("%c",&character) ;
    if(character=='a' || character=='e'|| character=='i' || character =='o' || character=='u'){
        printf("It's a vowel") ;
    }
    else{
        printf("It's a consonant") ;
    }
    return 0 ;
}