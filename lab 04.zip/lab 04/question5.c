#include <stdio.h>

int main(){
    int year ;
    printf("Enter Year : ") ;
    scanf("%d",&year) ;


    if( year %4 ==0 || year%400 == 0){
        printf("It's a leap year") ;
    }
    else if(year%100 != 100){
        printf("It's not a leap year") ;
    }
   
    return 0 ;
}